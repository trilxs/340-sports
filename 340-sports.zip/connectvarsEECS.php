<?php
  // Define database connection constants
  define('DB_HOST', 'classmysql.engr.oregonstate.edu');
  define('DB_USER', 'cs340_leed3');
  define('DB_PASSWORD', '2492');
  define('DB_NAME', 'cs340_leed3');
?>
