<!doctype html>
<div class="your-games-container">
        <div class="main-games-container">
        <div class="main-games-text">YOUR GAMES</div>
   
            <?php include("yourgames.php"); ?>
        </div>
        <div class="other-games-container">
        <div class="main-games-text">OTHER GAMES</div>
            
            <?php include("othergames.php"); ?>
            
        </div>
</div>
</html>