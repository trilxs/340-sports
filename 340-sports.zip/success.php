<!doctype html>

<head>
  <title>Registration success</title>
  <link rel="stylesheet" href="./css/success.css">
</head>

<div class="whole-screen">
    <div class="success-container">
        <div class="success-text">
            You have registered successfully!
            You will be redirected to the login page in 3 seconds...
        </div>
    </div>
</div>



<script type="text/javascript">   
function Redirect() 
{  
window.location="./login.php"; 
} 
setTimeout('Redirect()', 3000);   
</script>
</html>

	
